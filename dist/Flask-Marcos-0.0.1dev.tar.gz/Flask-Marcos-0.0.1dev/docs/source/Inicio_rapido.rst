.. _inicio_rapido:

Inicio rápido
=============