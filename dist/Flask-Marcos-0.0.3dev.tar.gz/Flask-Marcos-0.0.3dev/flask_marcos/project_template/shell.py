#!/usr/bin/env python

import os

from app import app

os.environ['PYTHONINSPECT'] = 'True'