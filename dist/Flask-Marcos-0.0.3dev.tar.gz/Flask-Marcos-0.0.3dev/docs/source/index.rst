
Bienvenido a Marcos
===================

.. image:: _static/logo-full.png
   :alt: Marcos: ERP containner, one drop at a time
   :class: floatingflask

Bienvenidos a la documentación de Marcos para programadores, esta documentación se divide en varias parte,
les recomiendo que empiecen por la :ref:`instalacion`, y luego sigan con el :ref:`inicio_rapido`, ademas del inicio
rápido también podrá encontrar varios :ref:`tutoriales` que le mostraran varios ejemplos de como utilizar a Marcos y
crear sus propias aplicaciones, si quiere conocer el funcionamiento de Marcos internamente, revise la documentación del
:ref:`api`. También es importante seguir los patrones de diseño definidos para utilización de mejores practicas el desarrollo y
para que de esta forma su código pueda ser entendido o mantenido por otros usuarios de la comunidad esto puede
encontrarlo en la sección de Marcos :ref:`patrones_de_diseno`.
