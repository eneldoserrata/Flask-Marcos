.. _patrones_de_diseno:

Patrones de diseño
==================